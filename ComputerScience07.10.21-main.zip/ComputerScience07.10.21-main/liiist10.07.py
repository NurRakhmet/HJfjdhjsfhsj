c =[]
for i in range (6):
    c.append(i *5)
    print(c)
    l=[]
    l.append(5)
    l.append(-6)
    print(l)
    l.extend(c)
    l.sort()
    

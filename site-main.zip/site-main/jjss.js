console.log ("Иван")
console.log (35)
console.log (true)
